from django.contrib import admin
from .models import MyUser

# Register your models here.
# admin.site.register(MyUser)

@admin.register(MyUser)
class UserAdmin(admin.ModelAdmin):
	list_display = ('user','jins','viloyat', 'tuman','created_by','created_at')
	list_filter = ('jins','viloyat','tuman','created_by','created_at')
	
